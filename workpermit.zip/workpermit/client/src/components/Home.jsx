import React from 'react'

export function Home () {
    return(
        <div>
            <h1>Home Page {user.username}</h1>
            <p>Welcome to work permit management page !</p>
        </div>
    )
}