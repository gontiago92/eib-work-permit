import React from 'react'

export function Dashboard () {
    return(
        <div>
            <h1>Dashboard</h1>
            <p>Welcome to work permit management Dashboard page !</p>
        </div>
    )
}