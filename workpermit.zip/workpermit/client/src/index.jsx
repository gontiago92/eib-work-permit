import React, { useState, useEffect } from 'react'
import { render } from 'react-dom'
import { BrowserRouter as Router, Route, Switch, Redirect } from 'react-router-dom'
import './index.sass'

/** JSX components */
import {Alert} from './components/Alert'
import {Nav} from './components/Nav'
import {Home} from './components/Home'
import {Dashboard} from './components/Dashboard'
import {Preferences} from './components/Preferences'
import {Login} from './components/Login'

const getStatus = async () => {
    const data = await fetch('http://localhost:2021/login')
    const status = await data.json()
    return status
}

function App (){

    const [isAuthenticating, setIsAuthenticating] = useState(true);
    const [isAuthenticated, userHasAuthenticated] = useState(false);
    const [user, setUser] = useState({});

    useEffect(() => {
        onLoad();
    }, []);
      
    async function onLoad() {
        try {
            const status = await getStatus()

            if(status?.error) {
                console.log("onLoad(error): ", status)
                userHasAuthenticated(false);
            } else if(status?.user || Object.keys(status.user).length > 0) {
                console.log('onLoad(success): ', status)
                userHasAuthenticated(true);
                //setUser(status?.user)
            }
        }
        catch(e) {
          if (e !== 'No current user') {
            alert(e);
          }
        }
      
        setIsAuthenticating(false);
    }

    if(!isAuthenticated) {
        return <Login setUser={setUser} load={onLoad} />
    }
    
    const logout = async credentials => {
        const data = await fetch('http://localhost:2021/logout')
        const status = await data.json()
    }


    const handleLogout = e => {
        e.preventDefault()
        console.log('Logging out...')
        logout()
        onLoad()
    }

    return (
        !isAuthenticating && (
            <div>
                <Nav handleLogout={handleLogout} />
                <div className="container-sm p-4">
                    <Switch>
                        <Route path="/dashboard" component={Dashboard} />
                        <Route path="/preferences" component={Preferences} />
                        <Route path="/" exact component={Home} />
                    </Switch>
                </div>
            </div>
        )
    )
}

render(
    <Router>
        <App />
    </Router>,
    document.getElementById('app')
)

