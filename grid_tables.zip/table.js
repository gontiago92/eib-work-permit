/*const wpheader = document.querySelector('.table-header')

window.addEventListener('scroll', function() {
    console.log(wpheader.scrollHeight)
    console.log(wpheader.scrollTop)
    console.log(wpheader.offsetTop)    
    console.log('Window :', this.scrollY)

    if(this.scrollY > wpheader.offsetTop) {
        wpheader.style.position = 'sticky'
        wpheader.style.top = '0px'
    } 
})*/