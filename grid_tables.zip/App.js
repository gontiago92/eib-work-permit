import React from 'react'
import FilterableTable from './components/FilterableTable'
import './public/assets/stylesheets/table.sass'

export default function App () {
    return (
        <div className="container">
            <h1>Application</h1>
            <FilterableTable />
        </div>
    )
}