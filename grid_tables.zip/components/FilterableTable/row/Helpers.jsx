import React from 'react'

function ClosedBtn({wpstatus}) {
    return  <button className="statusBtn closed">{wpstatus} <i className="fa fa-stop"></i></button>
}

function OpenedBtn({wpstatus}) {
    return  <button className="statusBtn opened">{wpstatus} <i className="fa fa-play"></i></button>
}

function StandbyBtn({wpstatus}) {
    return  <button className="statusBtn standby">{wpstatus} <i className="fa fa-pause"></i></button>
}

/**
 * Creates a button based on status of the permit
 * @param {*} status
 */
export function Buttons({wpstatus}) {
    return (
        <>
        { wpstatus == 'closed' && <ClosedBtn wpstatus={wpstatus} /> }
        { wpstatus == 'open' && <OpenedBtn wpstatus={wpstatus} /> }
        { wpstatus == 'standby' && <StandbyBtn wpstatus={wpstatus} /> }
        </>
    )
}

// Allowed days handler

function Allowed () {
    return <i className="fa fa-check-square"></i>
}
function NotAllowed () {
    return <i className="fa fa-window-close"></i>
}

/**
 * Creates an icon checked if allowed & a cross if not allowed
 * @param {Boolean} Boolean 
 */
export function AllowedDays ({nh, ph, bh}) {

    return (
        <>
        { nh ? <Allowed /> : <NotAllowed /> }
        { ph ? <Allowed /> : <NotAllowed /> }
        { bh ? <Allowed /> : <NotAllowed /> }
        </>
    )
}