import React, { useState } from 'react'
import {Buttons, AllowedDays} from './Helpers'



export default function Row ({type, data}) {
    //console.log(data)
    const [wpstatus, setWPstatus] = useState(data.status)

    return (
        <li className={`table-row ${wpstatus} ${type}`}>
            <div className="row">  
                <div className="col col-1" data-label="Type">
                    <Buttons wpstatus={wpstatus} />
                </div>
                <div className="col col-2" data-label="Company">{data.company}</div>
                <div className="col col-3" data-label="Work description">
                    {data.work_description}
                </div>
                <div className="col col-4 working_area" data-label="Working area">
                    <div>{data.working_area__general}</div>
                    <div className="separator"></div>
                    <div className="secondary">{data.working_area__exact}</div>
                </div>
                <div className="col col-5" data-label="Working days">
                    <div className="iconBox">
                        <AllowedDays 
                            nh={data.working_days__nh} 
                            ph={data.working_days__ph} 
                            bh={data.working_days__bh} />
                    </div>
                </div>
                <div className="col col-6" data-label="Valid">
                    <div>{data.valid_from}</div>
                    <div>{data.valid_until}</div>
                </div>
                <div className="col col-7" data-label="Person in charge">
                    {data.person_in_charge}
                </div>

            </div>

            <div className="row">
                <div className="col sub-col-1"  data-label="Permit number">
                    <div>Work Permit (wp)</div>
                    <div className="separator"></div>
                    <div>N° 19-0522</div>
                </div>
                <div className="col sub-col-2" data-label="Utils">
                    <div className="wp_utils">
                        <a href="#">
                          <i className="fa fa-print"></i>
                          <span>Print WP</span>
                        </a>
                        <a href="#">
                          <i className="fa fa-plus"></i>
                          <span>More info</span>
                        </a>
                        <a href="#">
                          <i className="fa fa-exclamation-triangle"></i>
                          <span>Report problem</span>
                        </a>
                        <a href="#">
                          <i className="fa fa-comments"></i>
                          <span>WP Comments</span>
                        </a>
                        <a href="#">
                          <i className="fa fa-history"></i>
                          <span>Openings history</span>
                        </a>
                    </div>
                </div>
            </div>
        </li>
    )
}