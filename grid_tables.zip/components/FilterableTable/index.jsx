import React, { useEffect, useState } from 'react'
import Row from './row'

export default function FilterableTable () {

    const [data, setData] = useState([])
    const [query, setQuery] = useState("")
    const [searchColumns, setSearchColumns] = useState(["company", "status"])
    
    useEffect(() => {
        fetchData()
    }, [])

    const fetchData = async () => {
        const data = await fetch(
            'https://raw.githubusercontent.com/gontiago92/eib-work-permit/main/data.json'
        )
        const items = await data.json()
            
        setData(items)
    }

    const filterByDate = (arr, query) => {
        return arr.filter(el =>  el.toLowerCase().indexOf(query.toLowerCase()) !== -1);
    }

    /*function search(rows) {
        console.log(rows[0] && Object.keys(rows[0]))
        return rows.filter(row => 
            row.status.toLowerCase().indexOf(query.toLowerCase()) > -1 ||
            row.company.toLowerCase().indexOf(query.toLowerCase()) > -1 ||
            row.working_area__general.toLowerCase().indexOf(query.toLowerCase()) > -1 ||
            row.person_in_charge.toLowerCase().indexOf(query.toLowerCase()) > -1
        )
    }*/

    function search(rows) {
        return rows.filter(row => 
            searchColumns.some(column => 
                row[column].toString().toLowerCase().indexOf(query.toLowerCase()) > -1)
        )
    }

    const columns = data[0] && Object.keys(data[0])

    return (
        <ul className="responsive-table">
            <li>
                <input type="search" value={query} placeholder="Search (Permit number, company)" onChange={e => setQuery(e.target.value) } />
                {
                    columns && columns.map(column => (
                            <>
                            <input type="checkbox" name="" id=""/>
                            <label>{column}</label>
                            </>
                        )
                        )
                }
            </li>
            <li className="table-header">
                <div className="col col-1">Type</div>
                <div className="col col-2">Company</div>
                <div className="col col-3">Work description</div>
                <div className="col col-4">Working Area</div>
                <div className="col col-5">
                    <div>Working days</div>
                    <div className="secondary">
                        <span>NH</span>
                        <span>PH</span>
                        <span>BH</span>
                    </div>
                </div>
                <div className="col col-6">
                    <div>Valid</div>
                    <div className="secondary">
                        <span>From</span>
                        <span>To</span>
                    </div>
                </div>
                <div className="col col-7 duo">
                    <div>Person in charge</div>
                    <div className="secondary">
                        <span>Lastname</span>
                        <span>Firstname</span>
                    </div>
                </div>
            </li>
            {search(data).map(row => (
                <Row type={row.row_type} key={row.id} data={row} />
            ))}
        </ul>
    )
}