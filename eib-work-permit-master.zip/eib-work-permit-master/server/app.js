import 'dotenv/config';
import cors from 'cors';
import express from 'express' 
import db from './lib/db.js';

const app = express();
 
app.use(cors());
app.use(express.json())

app.locals.session = {}
app.locals.session.user = {}

app.get('/', (req, res) => {
  res.status(301).redirect('/login')
})

app.get('/login', (req, res) => {
  console.log(app.locals.session.user)
  if(Object.keys(app.locals.session.user).length === 0)
    res.send({error: 'Unauthorized'})
  else
    res.send({user: app.locals.session.user})
  //console.log(req.body)
})

app.post('/login', (req, res) => {


  const { username, password } = req.body

  if(!username || !password) {
    return res.status(401).send({ error: "Please provide an email and a password !" })
  }

  db.query(`SELECT * FROM users WHERE username = ? OR email = ?`, [username, username], async (error, results) => {
      //console.log(await bcrypt.compare(password, results[0].password))
      //!(await bcrypt.compare(password, results[0].password))
      if(results.length < 1) {
          return res.send({ error: "Wrong credentials !" })
      }else {
          //app.locals.session.user = results[0];

          let __FOUND = results.find(function(user, index) {
            if(user.password == password)
                return true;
          });
          app.locals.session.user = __FOUND
          res.send({user: __FOUND})
      }
  })
})

app.get('/logout', (req, res) => {
  app.locals.session.user = {}
  res.send({user: app.locals.session.user})
})

app.use('/', (req,res) => {
  res.status(404).send('<h1>404 Page Not Found!</h1>');
});
 
app.listen(process.env.PORT, () =>
  console.log(`[ Server started ]\n[ Listening on port : ${process.env.PORT} ]`),
);
