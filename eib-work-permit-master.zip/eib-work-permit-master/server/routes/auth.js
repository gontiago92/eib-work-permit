const express = require('express')
const authController = require('../controllers/auth')

import {Router as router} from 'express'

router.post('/login', authController.login)

router.post('/register', authController.register)

router.get('/logout', authController.logout);

export default router