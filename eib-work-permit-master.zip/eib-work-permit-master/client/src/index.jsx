import React, { useState, useEffect } from 'react'
import { render } from 'react-dom'
import Axios from 'axios'
import { BrowserRouter as Router, Route, Switch, NavLink, Redirect } from 'react-router-dom'
import './index.sass'

/** JSX components */
import {Alert} from './components/Alert'
import {Nav} from './components/Nav'
import {Home} from './components/Home'
import {Dashboard} from './components/Dashboard'
import {Preferences} from './components/Preferences'
import {Login} from './components/Login'

function App () {

    useEffect(() => {
        getStatus()
    }, [loggedStatus]);
    
    const [user, setUser] = useState({});

    const [loggedStatus, setLoggedStatus] = useState(Boolean)

    const getStatus = async () => {
        const data = await fetch('http://localhost:2021/login')
        const status = await data.json()

        if(status?.error) {
            console.log(status.error)
        }
        else if(status?.user || Object.keys(status.user).length > 0) {
            setUser(status.user)
            setLoggedStatus(true)
            console.log(status)
        } 
    }

    const isLoggedIn = () => {
        return loggedStatus
    }
    //console.log(isLoggedIn())

    if(!isLoggedIn()) 
        return <Login setUser={setUser} />


    const logout = async credentials => {
        const data = await fetch('http://localhost:2021/logout')
        const status = await data.json()
        
        console.log(status)
    }


    const handleLogout = e => {
        e.preventDefault()
        console.log('can logout')
        logout()
    }

    return(
        <div>
                    {console.log(user)}
            <Nav handleLogout={handleLogout} />
            
            <div className="container-sm p-4">
                {/*console.log(Object.keys(status).length)*/}
                {/*<Alert type="danger" message={user} />*/}
                <Switch>
                    <Route path="/" exact component={Home} />
                    <Route path="/dashboard" component={Dashboard} />
                    <Route path="/preferences" component={Preferences} />
                </Switch>
            </div>
        </div>
    )
}

render(
    <Router>
        <App />
    </Router>,
    document.getElementById('app')
)

