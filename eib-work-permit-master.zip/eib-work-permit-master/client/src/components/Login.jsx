import React, {useState} from 'react'

import eiblogo from '../assets/images/eiblogo.png';

export function Login ({setUser}) {

    
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = async e => {
        e.preventDefault();

        /*if(username === '' || password === '') {
            alert('Please provide an email or username and a password !')
            return false
        }*/
            
        const newStatus = await loginUser({
            username: username,
            password: password
        });

        setUser(newStatus)
        /*if(newStatus.error)
            setStatus(newStatus.error)*/
      }

    async function loginUser(credentials) {
        return fetch('http://localhost:2021/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(credentials)
        }).then(data => data.json())
    }

    return(
    <div>
        <header>
            <img src={eiblogo} alt=""/>
        </header>
        <div className="container mt-4 pt-4">
            <div className="row text-center">
                <h1 className="display-5">GESTION DES INFORMATIONS PREALABLE ET/OU PERMIS DE TRAVAIL</h1>
            </div>
            <div className="row text-center">
                <h2 className="display-6">GESTION COORDONNÉE / SÉCURITÉ</h2>
            </div>
            <div className="row mt-4 justify-content-md-center">
            <form onSubmit={e => handleSubmit(e)} className="col-md-auto card p-4">
                <div className="alert alert-info">
                    {username + " - " + password}
                </div>

                <div className="mb-4">
                    <input type="text" placeholder="Username or email" className="form-control" onChange={(e) => setUsername(e.target.value)}/>
                </div>
                <div className="mb-4">
                    <input type="password" placeholder="Password" className="form-control" onChange={(e) => setPassword(e.target.value)}/>
                </div>

                <button className="btn btn-primary" type="submit">Login</button>

                <div className="row my-2">
                    <div className="col-sm">
                        <a href="#" className="link">Mot de passe oublié ?</a>
                    </div>
                    <div className="col-sm">
                        <a href="#" className="link">Quand utiliser un PT, une IP ou une Dérogation ?</a>
                    </div>
                </div>
            </form>
            </div>
            
        </div>
        </div>
    )
}