import React, {useState} from 'react'
import PropTypes from 'prop-types'
import eiblogo from '../assets/images/eiblogo.png';

async function loginUser(credentials) {
    return fetch('http://localhost:2021/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    }).then(data => data.json())
}

export function Login ({setUser}) {

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("")

    const handleSubmit = async e => {
        e.preventDefault();


        const newStatus = await loginUser({
            username: username,
            password: password
        });

        //status?error && setError(status?.error)
        console.log(newStatus)
        //setUser(newStatus)
        /*if(newStatus.error)
            setStatus(newStatus.error)*/
      }

    return(
    <div>
        <header>
            <img src={eiblogo} alt=""/>
        </header>
        <div className="container mt-4 pt-4">
            <div className="row text-center">
                <h1 className="display-5">GESTION DES INFORMATIONS PREALABLE ET/OU PERMIS DE TRAVAIL</h1>
            </div>
            <div className="row text-center">
                <h2 className="display-6">GESTION COORDONNÉE / SÉCURITÉ</h2>
            </div>

            <div className="row mt-4 justify-content-md-center">
            <form onSubmit={e => handleSubmit(e)} className="col-md-auto card p-4">

                <div className="alert alert-danger">
                    {error}
                </div>

                <div className="row mb-4">
                    <div className="col-sm">
                        <input type="text" placeholder="Username or email" className="form-control" onChange={(e) => setUsername(e.target.value)}/>
                        <div id="passwordHelpBlock" className="form-text">
                            {username}
                        </div>
                    </div>
                    <div className="col-sm">
                        <input type="password" placeholder="Password" className="form-control" onChange={(e) => setPassword(e.target.value)}/>
                        <div id="passwordHelpBlock" className="form-text">
                            {password}
                        </div>
                    </div>

                </div>

                <button className="btn btn-primary" type="submit">Login</button>

                <div className="row mt-4">
                    <a href="#" className="link">Mot de passe oublié ?</a>

                    <a href="#" className="link">Quand utiliser un PT, une IP ou une Dérogation ?</a>
                </div>
            </form>
            </div>
            
        </div>
        </div>
    )
}

Login.propTypes = {
    setUser: PropTypes.func.isRequired
}