import React from 'react'

export function Preferences () {
    return(
        <div>
            <h1>Preferences</h1>
            <p>Welcome to work permit management Preferences page !</p>
        </div>
    )
}