import React from 'react'

export function Home () {
    return(
        <div>
            <h1>Home Page</h1>
            <p>Welcome to work permit management page !</p>
        </div>
    )
}