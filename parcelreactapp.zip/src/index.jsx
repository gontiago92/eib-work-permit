import {render} from 'react-dom'
import React, { useEffect } from 'react'
import './index.sass'
import CodLogo from './CodLogo'
import * as cod from 'call-of-duty-api'
import { async } from 'q'

/*class CodAPI extends React.Component {
    constructor(props) {
        super(props)
        this.API = cod
    }

    componentDidMount() {
        async () => {
            try {
                console.log('here')
                await this.API.login();
             } catch(Error) {
                 //Handle Exception
                 console.log('error')
             }
        }
        
        
    }

    render() {
        return <div>
            <h3>CallOfDuty Api</h3>
        </div>
    }
}*/

function CodAPI() {
    const API = require('call-of-duty-api')({ platform: "battle" });
    useEffect(() => {
        handleLogin()
    },[])

    const handleLogin = async () => {
        console.log(API.login('tiago.goncalves.faria@gmail.com', 'onegaishimasu92'))
        const data= await API.login('tiago.goncalves.faria@gmail.com', 'onegaishimasu92')
        //let data = await API.MWcombatwz('LuxGamerPT', 'psn');
        console.log(data)
         
    }

   return <div>test</div>
}

render(
    <div className="container">
        <CodLogo width="200px" />

        <CodAPI />
        <p>Testing call of duty api</p>
        
    </div>,
    document.getElementById('app')
)

