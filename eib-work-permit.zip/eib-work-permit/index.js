import App from './App.js'


const root = document.getElementById('root')
ReactDOM.render(<App />, root)