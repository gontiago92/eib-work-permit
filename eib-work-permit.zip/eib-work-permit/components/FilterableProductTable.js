const PRODUCTS = [
    {category: "Sporting Goods", price: "$49.99", stocked: true, name: "Football"},
    {category: "Sporting Goods", price: "$9.99", stocked: true, name: "Baseball"},
    {category: "Sporting Goods", price: "$29.99", stocked: false, name: "Basketball"},
    {category: "Electronics", price: "$99.99", stocked: true, name: "iPod Touch"},
    {category: "Electronics", price: "$399.99", stocked: false, name: "iPhone 5"},
    {category: "Electronics", price: "$199.99", stocked: true, name: "Nexus 7"}
];


function ProductCategoryRow({category}) {
    return <tr>
        <th colSpan="2">{category}</th>
    </tr>
}

function ProductRow({product}) {
    const name = product.stocked ? true : false

    return <tr>
        <td>{product.name}</td>
        <td>{product.price}</td>
    </tr>
}

function ProductTable({products}) {
    const rows = []
    let lastCategory = null

    products.map(product => {

        if(product.category !== lastCategory) {
            rows.push(
                <ProductCategoryRow key={product.category} category={product.category} />
            )
        }

        rows.push(
            <ProductRow key={product.name} product={product} />
        )
        lastCategory = product.category
    })

    return <table className="box">
        <thead className="head">
            <tr>
                <th>Name</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody className="body">
            {rows}
        </tbody>
    </table>
}

export default class FilterableProductTable extends React.Component {

    render() {
        return (
            <div>
                <ProductTable products={PRODUCTS} />
            </div>
        )
    }

}