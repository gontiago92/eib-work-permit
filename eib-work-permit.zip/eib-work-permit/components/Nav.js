export default class Nav extends React.Component {
    render() {
      return <nav>
          <h3 className="logo">LOGO</h3>
          <div className="links">
              <a href="#">Home</a>
              <a href="#">About</a>
              <a href="#">Projects</a>
              <a href="#">Contact</a>
          </div>
      </nav>
    }
}