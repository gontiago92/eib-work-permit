import Nav from './components/Nav.js'
import FilterableProductTable from './components/FilterableProductTable.js'

export default function App() {
    
    return <div>
        <Nav />
        <h1>Work Permit</h1>
        <FilterableProductTable />
    </div>

}